# Pdi Project > ReSplit 
https://universe.roboflow.com/pdi-proyecto/pdi-project-q6mwb

Provided by a Roboflow user
License: CC BY 4.0

